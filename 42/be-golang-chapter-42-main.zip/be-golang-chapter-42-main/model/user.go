package model

type User struct {
	Id    uint16 `exampel:"1"`
	Name  string `example:"Lumoshive-academy"`
	Email string `example:"lumoshive.academy@example.com"`
	Phone string `example:"085305395395"`
}
